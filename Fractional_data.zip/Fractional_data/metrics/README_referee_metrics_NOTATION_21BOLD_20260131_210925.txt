OUTDIR: /Users/wenwenli/inverse_mcmc_fractional_20260118_105241
Completed trials: 10
n_obs (data locations): 507
n_iter: 80000, burn_in_user: 30000

Key outputs written under:
/Users/wenwenli/inverse_mcmc_fractional_20260118_105241/report_stage_referee_metrics_relerr_NOTATION_21BOLD

Plot outputs:
  - For each metric plot, BOTH .png and .pdf are saved (same basename).

Plot styling:
  - axis titles and tick labels: 21pt, bold
  - y-axis label: metric notation only (no extra text)
  - x-axis: parsed estimator notation (hat{u}_mean vs hat{u}_mode etc.)
